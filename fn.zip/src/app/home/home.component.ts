import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Pdtdata } from '../pdtdata';
import { ProductsService } from '../products.service';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  title = 'angularConnecMongoDB';
  public response: Observable<Pdtdata[]>
  data: any = [];
  public sampleData: any[] = [];
  displayVal: string = '';
  constructor(private pdtservice: ProductsService, private http: HttpClient, private router: ActivatedRoute) {
    this.response = this.pdtservice.fetchAPI();
    this.pdtservice.fetchAPI().subscribe(data => {
      this.sampleData = data;
    })
  }
  onSubmit(data: any) {
    this.http.post('http://localhost:2000/api/employee', data)
      .subscribe((result) => {
        console.warn("result", result)
        this.pdtservice.fetchAPI().subscribe(data => {
          this.sampleData = data;
        })
      })
    console.warn(data);
  }



  deleteProduct(employeeId: any) {

    this.pdtservice.deleteProduct(employeeId).subscribe((result: any) => {
      console.warn('result', result)
      this.pdtservice.fetchAPI().subscribe(data => {
        this.sampleData = data;
      })
    })
  }

  getValue(val: string) {
    if (val === "") {
      this.pdtservice.fetchAPI().subscribe(data => {
        this.sampleData = data;
      })
    }
    else {
      //console.warn(val);
      this.sampleData = [];
      this.pdtservice.getapi().subscribe((data: any) => {
        // this.data=data;
        //console.log(data);

        for (let i = 0; i < data.length; i++) {
          if (val == data[i].firstName) {
            //console.warn(data[i]._id)
            this.pdtservice.getCurrentProductData(data[i]._id).subscribe((result: any) => {
              //console.warn(result);
              this.sampleData.push(result);
              this.response = (result);

            })
          }
        }
      })
    }
  }

  ngOnInit() {
    this.pdtservice.fetchAPI().subscribe((data: any) => {
      this.data = data;
      console.log(data);
    })
  }

}