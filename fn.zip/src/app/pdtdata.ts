export interface Pdtdata {
    
    _id: any,
    employeeId: string,
    firstName: string,
    lastName: string,
    address: string,
    phoneNumber: string,
    location:string,
}
