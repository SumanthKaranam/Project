import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Cart, Foods } from 'src/app/shared/food';
import { HttpService } from 'src/app/services/http.service';
@Component({
  selector: 'app-salads',
  templateUrl: './salads.component.html',
  styleUrls: ['./salads.component.css'],
})
export class SaladsComponent implements OnInit {
  foods: Foods[] = [];

  constructor(private route: ActivatedRoute, private hs: HttpService) {}

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      if (params['searchItem']) {
        this.hs.getByName(params['searchItem']).subscribe((data) => {
          this.foods = data;
          console.log(data);
        });
        // this.foods = this.fs.getAll().filter(food => food.name.toLowerCase().includes(params['searchItem'].toLowerCase()))}
      } else {
        // this.foods = this.fs.FoodByTag(params['tag'])
        this.hs.getByTag('Salad').subscribe((data) => {
          this.foods = data;
          console.log(data);
        });
      }

      // else{

      //   this.foods = this.fs.getAll();

      // }
    });
  }
  cart = new Cart();
  userId: any = sessionStorage.getItem('userId');
  addToCart(food: Foods) {
    this.cart.userId = this.userId;
    this.cart.id = food.id;
    this.cart.image = food.image;
    this.cart.name = food.name;
    this.cart.origins = food.origins;
    this.cart.tags = food.tags;
    this.cart.price = food.price;
    this.hs.postToCart(this.cart).subscribe((data) => {
      console.log(data);
    });
  }
}
