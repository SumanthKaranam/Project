import { Component, OnInit, OnChanges } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { HttpService } from "src/app/services/http.service";

@Component({
  selector: "app-customer-contact",
  templateUrl: "./customer-contact.component.html",
  styleUrls: ["./customer-contact.component.css"]
})
export class CustomerContactComponent implements OnInit {
  
  
  loading = false;
  buttionText = "Submit";

  emailFormControl = new FormControl("", [
    Validators.required,
    Validators.email
  ]);

  nameFormControl = new FormControl("", [
    Validators.required,
    Validators.minLength(4)
  ]);

  contactFormControl = new FormControl("", [
    Validators.required
  ]);

  messageFormControl = new FormControl("", [
    Validators.required
  ]);



  constructor(public http: HttpService) {}

  ngOnInit() {
    console.log(this.http.test);
  }

  

  register() {
    this.loading = true;
    this.buttionText = "Submiting...";
    let user = {
      name: this.nameFormControl.value,
      email: this.emailFormControl.value,
      contact: this.contactFormControl.value,
      message: this.messageFormControl.value
    }
    this.http.sendEmail("http://localhost:3000/sendmail", user).subscribe(
      (      data: any) => {
        let res:any = data; 
        console.log(
          ` ${user.name} is successfully submitted your feedback and response mail has been sent and the message id is ${res.messageId}`
        );
      },
      (      err: any) => {
        console.log(err);
        this.loading = false;
        this.buttionText = "Submit";
      },() => {
        this.loading = false;
        this.buttionText = "Submit";
      }
    );
  }
}