import { Component, OnInit } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';
import { Cart } from 'src/app/shared/food';

@Component({
  selector: 'app-customer-cart',
  templateUrl: './customer-cart.component.html',
  styleUrls: ['./customer-cart.component.css'],
})
export class CustomerCartComponent implements OnInit {
  cart!: Cart;
  constructor(private hs: HttpService) {
    // this.setCart();
  }

  foods: Cart[] = [];
  userId: any = sessionStorage.getItem('userId');

  //pagination
  p:number = 1;
  count:number = 4;
  
  ngOnInit(): void {
    this.hs.getToCart(this.userId).subscribe((data) => {
      this.foods = data;
    });
  }

  // setCart(){

  //   this.cart = this.cartService.getCart();

  // }

  // removeFromCart(cartItem: CartItem){

  //   this.cartService.removeFromCart(cartItem.food.id);

  //   this.setCart();

  // }

  // changeQuantity(cartItem:CartItem, quantityInString:string){

  //   const quantity = parseInt(quantityInString);

  //   this.cartService.changeQuantity(cartItem.food.id, quantity);

  //   this.setCart();

  // }

  removeProduct(item: any) {
    // this.cart.removeCartItem(item);
    this.hs.deletefromcart(item.id).subscribe((data) => {
      console.log(data);
      this.ngOnInit();
    });
  }
  //removing all products of a particular user id
  removeAllProduct() {
    // this.cart.removeAllCart();
    console.log('error');
    this.hs
      .deleteallcart(this.userId)
      .subscribe((data) => {
        console.log(data);
        this.ngOnInit();
      });
  }
}
