
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { PasswordValidators } from './passwordValidators';

@Component({
selector: 'app-register',
templateUrl: './register.component.html',
styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

"registerForm":FormGroup;
isRegistered = false;

frm:any;

public response: any;
public reg:any;

constructor(private formBuilder: FormBuilder, public service: AuthService, public route:Router) {
this.reg = {
username: "",
password:"",
repassword:""
}
}

ngOnInit(): void {
this.registerForm = this.formBuilder.group({
username: ['', Validators.required],
email:['',
[Validators.required,
Validators.email]],
password: ['',
[Validators.required,
Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,12}$')]],
repassword: ['',
[Validators.required,
Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,12}$')]]
},
{
validator:PasswordValidators("password", "repassword")
});


this.service.getData().subscribe(data=>{
this.response = data;
//console.log(this.response)
})
}

get formControls1() {
return this.registerForm.controls;
}

register() {
console.log(this.registerForm.value);
this.isRegistered = true;
if(this.registerForm.invalid) {
return;
}
}

passwordMatch(){
return
}


public addData() {
//console.log(this.reg)
this.service.postData(this.registerForm.value)
.subscribe(data=> {
//-console.log(data)
//window.alert(data)
this.refreshData()
alert("Register Successful")

})
}

public refreshData() {
this.service.getData().subscribe(data=>{
this.response = data;
//console.log(this.response)
})

}

Reset():void {
this.isRegistered=false;
this.registerForm.reset();
}
}

