import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  count:any;
 

  constructor() { }

  min:any;

  max:any;

  ngOnInit(): void {



   const temp = sessionStorage.getItem("count")

    this.count = Number(temp);

    this.max = false;

    this.min = false;

    if(this.count == 0){

      this.min = true;

    }
    if(this.count == 15){

      this.max = true;

    }

    console.log(this.count);

  }

  public getCount(){

    return this.count

  }

  public decCount(){

    this.count -= 1;

   

    let temp1 = this.count.toString();

    sessionStorage.setItem("count", temp1 )



    // console.log("count");

  }

  public incCount(){

    this.count += 1;

   

    let temp1 = this.count.toString();

    sessionStorage.setItem("count", temp1 )



    // console.log("count");

  }

}


