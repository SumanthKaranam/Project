import { Component, OnInit } from '@angular/core';
import { ReserveService } from 'src/app/services/reserve.service';


@Component({
  selector: 'app-cancel',
  templateUrl: './cancel.component.html',
  styleUrls: ['./cancel.component.css']
})
export class CancelComponent implements OnInit {

  public cancel:any
  public response: any;

  constructor(public service:ReserveService) { 
    this.cancel = {
      codename: ""
    }
  }

  ngOnInit(): void {
    this.service.getData().subscribe(data=> {
      this.response = data;
      console.log(data)
    })
  }

  cancelReservation() {
    this.service.deleteData(this.cancel)
    .subscribe(data=> {
      console.log(data)
      this.refreshData();
    })
    alert("Cancelled Successfully")
  }

  public refreshData() {
    this.service.getData().subscribe(data => {
      this.response = data;
      console.log(this.response);
    })
  }
}
