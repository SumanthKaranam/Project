import { Component, OnInit } from '@angular/core';
import { resetFakeAsyncZone } from '@angular/core/testing';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ReserveService } from 'src/app/services/reserve.service';


@Component({
  selector: 'app-reserve',
  templateUrl: './reserve.component.html',
  styleUrls: ['./reserve.component.css']
})
export class ReserveComponent implements OnInit {

  "reserveForm":FormGroup;
  isRegistered = false;

  public response: any;
  public reserve: any;
 
  constructor(private formBuilder: FormBuilder, public service:ReserveService, public route:Router) { 
    this.reserve = {
      username: "",
      contact: "",
      codename: ""
    }
  }

  ngOnInit(): void {
    this.reserveForm = this.formBuilder.group({
      username: ['', Validators.required],
      contact: ['', Validators.required],
      codename: ['', Validators.required],
      
    });

    this.service.getData().subscribe(data=> {
      this.response = data;
      //console.log(data)
    })
  }

  get formControls() {
    return this.reserveForm.controls;
  }

  reservation() {
    console.log(this.reserveForm.value)
    this.isRegistered = true;
    if(this.reserveForm.invalid) {
      return;
    }
  }

  onSubmit():void {
    this.isRegistered = true;
    if(this.reserveForm.invalid) {
      return;
    }
  }
 
  onReset():void {
    this.isRegistered=false;
    this.reserveForm.reset();
  }

  temp:any; 

  public makeReservation() {
    this.service.postData(this.reserveForm.value)
    .subscribe(data=> {
      console.log(data)
      this.refreshData()
      //
      this.temp = data;
      if(this.temp.message == 'success'){

        sessionStorage.setItem("userId", this.temp.id);
      
        console.log(this.temp.id);
      
        this.route.navigate(['/registration']);
      
      }
      //
    })
    //this.route.navigate(['/registration'])
    alert("Registration success")
  }

  public refreshData() {
    this.service.getData().subscribe(data => {
      this.response = data;
      console.log(this.response);
    })
  }

}
