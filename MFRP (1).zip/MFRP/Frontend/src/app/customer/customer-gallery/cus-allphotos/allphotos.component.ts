import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allphotos',
  templateUrl: './allphotos.component.html',
  styleUrls: ['./allphotos.component.css']
})
export class AllphotosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
