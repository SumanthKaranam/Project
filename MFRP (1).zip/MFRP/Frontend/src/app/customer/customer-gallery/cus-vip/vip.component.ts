import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vip',
  templateUrl: './vip.component.html',
  styleUrls: ['./vip.component.css']
})
export class VipComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
