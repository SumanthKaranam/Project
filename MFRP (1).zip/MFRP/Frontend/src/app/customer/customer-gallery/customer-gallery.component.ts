import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-gallery',
  templateUrl: './customer-gallery.component.html',
  styleUrls: ['./customer-gallery.component.css']
})
export class CustomerGalleryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
