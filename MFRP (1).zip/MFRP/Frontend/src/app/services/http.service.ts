import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Cart } from "../shared/food";

@Injectable({
  providedIn: "root"
})
export class HttpService {
  test = "How r u?";
  constructor(private http: HttpClient) {}

  httpGet(url: string) {
    return this.http.get(url);
  }

  httpPost(url: string, {}: any) {
    return this.http.post(url, { name: "Subrat" });
  }

  sendEmail(url: string, data: any) {
    return this.http.post(url, data);
  }

  getByName(name: string): Observable<any> {
    return this.http.get<any>('http://localhost:1000/api/getByName/' + name);
    }
    
    getByTag(name: string): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:1000/api/getByTag/' + name);
    }
    
    postToCart(data: Cart): Observable<any> {
    return this.http.post<any>('http://localhost:1000/api/addToCart', data);
    }
    
    getToCart(id: String): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:1000/api/getCart/' + id);
    }
    
    deletefromcart(id:number):Observable<any>{
    const headers = {'content-type':'application/json'}
    var temp = {
    "id": id,
    "userId": sessionStorage.getItem("userId")
    
    }
    const body = JSON.stringify(temp);
    return this.http.post<any>("http://localhost:1000/api/delcartitem", body,{'headers':headers})
    
    }
    deleteallcart(id:string):Observable<any>{
    return this.http.delete<any>("http://localhost:1000/api/delallitems/" +id )
    }
}