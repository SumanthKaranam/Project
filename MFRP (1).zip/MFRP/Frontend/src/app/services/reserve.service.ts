import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Table } from '../shared/table'

@Injectable({
  providedIn: 'root'
})
export class ReserveService {

  url = "http://localhost:1000/api/";
  

  constructor(private http :HttpClient) { }

  public getData():Observable<Table[]> 
  {
    return this.http.get<Table[]>(this.url+'reserve')
  }

  public postData(detail:Table):Observable<any>
  {
    const headers = {'content-type': 'application/json'};
    const body = JSON.stringify(detail)
    return this.http.post(this.url+'reserve',body,{'headers':headers})
  }

  public deleteData( detail:Table):Observable<any>
  {
    return this.http.delete(this.url+'cancel/'+ detail.codename)
  }
}
