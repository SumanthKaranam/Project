import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { Idata } from '../shared/idata';
import { Login } from '../shared/login';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  url = "http://localhost:1000/api/";

  constructor(private http: HttpClient) { }

  public getData(): Observable<Idata[]> {
    return this.http.get<Idata[]>(this.url + 'register')
  }

  public postData(register: Idata): Observable<any> {
    const headers = { 'content-type': 'application/json' };
    const body = JSON.stringify(register)
    return this.http.post(this.url + 'register', body, { 'headers': headers })
  }

  public postLogin(login: Idata): Observable<any> {
    return this.http.post(this.url + 'login', login)
  }

  public getLogin(id:String):Observable<Login[]>
  {
    return this.http.get<any[]>(this.url+'login/'+ id);
  }

}
