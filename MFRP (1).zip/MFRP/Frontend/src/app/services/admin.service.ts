import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Menu } from '../shared/adminMenu';


@Injectable({
  providedIn: 'root'
})
export class AdminService {

  url="http://localhost:1000/api/"

  constructor(private http: HttpClient) { }

  public addMenu(menu:Menu): Observable<any>
  {
    const headers = {'content-type':'application/json'};
    const body = JSON.stringify(menu)
    return this.http.post(this.url+'add',body,{'headers':headers})
  }

  public getMenu():Observable<Menu[]>
  {
    return this.http.get<Menu[]>(this.url+ 'getMenu')
  }

  public getbyTag(tags:string[]):Observable<any>
  {
    return this.http.get<any>(this.url+'getByTag/'+ tags)
  }

  public updateItem(menu:Menu):Observable<any>
  {
    return this.http.put(this.url+'updateMenu',menu)
  }

  public deleteItem(menu:Menu):Observable<any>
  {
    return this.http.delete(this.url+'deleteFood/'+menu.name)
  }
}
