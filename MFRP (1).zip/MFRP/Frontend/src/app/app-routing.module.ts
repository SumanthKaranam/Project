import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './Public/about/about.component';
import { ContactUsComponent } from './Public/contact-us/contact-us.component';
import { AllphotosComponent } from './gallery/allphotos/allphotos.component';
import { EventsComponent } from './gallery/events/events.component';
import { FoodComponent } from './gallery/food/food.component';
import { GalleryComponent } from './gallery/gallery.component';
import { InteriorComponent } from './gallery/interior/interior.component';
import { VipComponent } from './gallery/vip/vip.component';
import { CustomerNavbarComponent } from './customer/customer-navbar/customer-navbar.component';

import { LogoutComponent } from './logout/logout.component';
import { CustomerCartComponent } from './customer/customer-cart/customer-cart.component';
import { BreadsComponent } from './menu/breads/breads.component';
import { BreakfastComponent } from './menu/breakfast/breakfast.component';
import { DinnerComponent } from './menu/dinner/dinner.component';
import { FastFoodComponent } from './menu/fast-food/fast-food.component';
import { LunchComponent } from './menu/lunch/lunch.component';
import { SaladsComponent } from './menu/salads/salads.component';
import { CustomerHomeComponent } from './customer/customer-home/customer-home.component';
import { CustomerAboutComponent } from './customer/customer-about/customer-about.component';
import { CustomerGalleryComponent } from './customer/customer-gallery/customer-gallery.component';
import { CustomerContactComponent } from './customer/customer-contact/customer-contact.component';
import { AdminComponent } from './adminpage/admin/admin.component';
import { AdminLoginComponent } from './adminpage/admin-login/admin-login.component';
import { HomeComponent } from './Public/home/home.component';
import { RegistrationComponent } from './customer/TableBooking/registration/registration.component';
import { ReserveComponent } from './customer/TableBooking/reserve/reserve.component';
import { CancelComponent } from './customer/TableBooking/cancel/cancel.component';
import { PaymentComponent } from './customer/payment/payment.component';
import { LoginComponent } from './customer/login/login.component';
import { RegisterComponent } from './customer/register/register.component';


const routes: Routes = [
  {path:"", pathMatch:"full", redirectTo:"home"},
  {path:"home", component:HomeComponent},
  {path:"gallery", component:GalleryComponent, 
    children:[{path:"all", component:AllphotosComponent}, {path:"interior", component:InteriorComponent}, {path:"food",component:FoodComponent}, {path:"events", component:EventsComponent}, {path:"vip", component:VipComponent}]},
  {path: "contact-us", component:ContactUsComponent},
  {path: "about", component:AboutComponent},
  {path:"admin-login", component:AdminLoginComponent},
  {path:"admin", component:AdminComponent},
  {path: "login", component:LoginComponent},
  {path: "register", component:RegisterComponent},
  {path: "customer", component:CustomerNavbarComponent},
  {path: "customer-home", component:CustomerHomeComponent},
  {path:"customer-about", component:CustomerAboutComponent},
  {path:"customer-gallery",component:CustomerGalleryComponent,
  children:[{path:"cus-allphotos", component:AllphotosComponent}, {path:"cus-interior", component:InteriorComponent}, {path:"cus-food",component:FoodComponent}, {path:"cus-events", component:EventsComponent}, {path:"cus-vip", component:VipComponent}]},
  {path:"customer-contact", component:CustomerContactComponent},
  {path:"registration", component:RegistrationComponent},
  {path:"logout", component:LogoutComponent},
  {path:"reserve", component:ReserveComponent},
  {path:"cancel", component:CancelComponent},
  {path:"breads", component:BreadsComponent},
  {path:"breakfast", component:BreakfastComponent},
  {path:"dinner", component:DinnerComponent},
  {path:"fast-food", component:FastFoodComponent},
  {path:"lunch", component:LunchComponent},
  {path:"salads", component:SaladsComponent},
  {path:"cart-page", component:CustomerCartComponent},
  {path:"payment", component:PaymentComponent},
  {path:"search/:searchItem", component:BreakfastComponent},
  {path:"tag/:tag", component:BreakfastComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
