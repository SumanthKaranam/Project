import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { AuthService } from 'src/app/services/auth.service';
import { HttpService } from 'src/app/services/http.service';
import { ReserveService } from 'src/app/services/reserve.service';
import { Cart } from 'src/app/shared/food';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  temp: boolean = false;
  password = '';

  public response:any;
  public menu:any;

  public users: any;
  public register:any;

  public reservers:any;
  public reserve: any;

  cart!: Cart;

  foods: Cart[] = [];
  userId: any = sessionStorage.getItem('userId');


  constructor(public service:AdminService, public registers: AuthService, public server:ReserveService, private hs: HttpService) {
    this.menu = {
      id:"",
      name:"",
      price:"",
      tags: "",
      image:"",
      origins:""
    }

     this.register = {
      username:"",
      password:""
    }

    this.reserve = {
      username:"",
      contact:"",
      codename:""
    }
   }

  ngOnInit(): void {
    this.service.getMenu().subscribe(data => {
      this.response = data;
      console.log(data);
    })

    // this.registers.getData().subscribe(data=> {
    //   this.users = data;
    //   console.log(data)
    // })
    
    this.server.getData().subscribe(data => {
      this.reservers = data;
      console.log(data);
    })

    this.registers.getLogin(this.userId).subscribe((data) => {
      this.users = data;
    })

    this.hs.getToCart(this.userId).subscribe((data) => {
      this.foods = data;
      console.log(data);
    });
  }

  clicked() {
    if (this.password == 'QWER12!qwer') {
      this.temp = true;
    }
  }


  // onFileChange(event:any) {
  //   const reader = new FileReader();
    
  //   if(event.target.files && event.target.files.length) {
  //     const [file] = event.target.files;
  //     reader.readAsDataURL(file);
    
  //     reader.onload = () => {
   
  //       this.imageSrc = reader.result as string;

  //       this.menu.image = reader.result as string;
     
  //       this.response.patchValue({
  //         fileSource: reader.result
  //       });
   
  //     };
   
  //   }
  // }

  public addFood() {
    this.service.addMenu(this.menu)
    .subscribe(data => {
      console.log(data)
      this.refreshMenu();
    })
  }
  
  public searchItem() {
    this.service.getbyTag(this.menu.tags)
    .subscribe(data => {
      //console.log(JSON.stringify(data))
      this.response = data;
      //this.response.push(JSON.stringify(data))
    })
  }

  public updateFood(){
    this.service.updateItem(this.menu)
    .subscribe(data=> {
      console.log(data)
      this.refreshMenu();
    })
  }

  public deleteFood() {
    this.service.deleteItem(this.menu)
    .subscribe(data => {
      console.log(data)
      this.refreshMenu();
    })
  }

  public refreshMenu() {
    this.service.getMenu().subscribe(data => {
      this.response = data;
    })
  }
  
}
