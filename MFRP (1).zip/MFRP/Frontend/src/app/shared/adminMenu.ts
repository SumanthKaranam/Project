export interface Menu{
    id : number;
    name : string;
    price : string;
    tags : string[];
    image : string;
    origins: string;
}