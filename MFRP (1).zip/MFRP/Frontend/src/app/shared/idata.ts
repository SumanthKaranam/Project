export interface Idata {
    username: string;
    password: string;
    repassword: string;
}
export class response{

    message!: string;
    success!: boolean;
    id!: string;
  
}