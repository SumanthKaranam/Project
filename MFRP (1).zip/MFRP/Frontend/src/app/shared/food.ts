export class Foods {

  id!: number;

  price!: number;

  name!: string;

  favorite: boolean = false;

  

  tags?: string[];

  image!: string;

  

  origins!: string;

}

export class Cart {

  removeCartItem(item: any) {

    throw new Error('Method not implemented.');

  }

  userId!: String;

  username!: String;

  id!: number;



  price!: number;



  name!: string;



  tags?: string[];



  image!: string;



  origins!: string;

}