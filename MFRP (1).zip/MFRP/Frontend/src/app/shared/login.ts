export interface Login {
    userId: string,
    username: string;
    password: string;
}