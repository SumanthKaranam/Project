export interface Table {
    username: string;
    contact: string;
    codename: string;
}
