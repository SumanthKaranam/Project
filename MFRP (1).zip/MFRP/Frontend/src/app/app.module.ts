import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FlexLayoutModule } from '@angular/flex-layout';

import { AppRoutingModule } from './app-routing.module';
import {MatToolbarModule} from '@angular/material/toolbar';

import { MatSidenavModule } from '@angular/material/sidenav';

import { MatListModule } from '@angular/material/list';

import {MatIconModule} from '@angular/material/icon';

import { MatButtonModule } from '@angular/material/button';

import { MatMenuModule } from '@angular/material/menu';

import { MatChipsModule } from '@angular/material/chips';

import {MatButtonToggleModule} from '@angular/material/button-toggle';


import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { CustomerNavbarComponent } from './customer/customer-navbar/customer-navbar.component';
import { CustomerCartComponent } from './customer/customer-cart/customer-cart.component';
import { GalleryComponent } from './gallery/gallery.component';
import { AllphotosComponent } from './gallery/allphotos/allphotos.component';
import { InteriorComponent } from './gallery/interior/interior.component';
import { EventsComponent } from './gallery/events/events.component';
import { VipComponent } from './gallery/vip/vip.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { Material } from './app-material';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { LogoutComponent } from './logout/logout.component';
import { CustomerHomeComponent } from './customer/customer-home/customer-home.component';

import { BreadsComponent } from './menu/breads/breads.component';
import { BreakfastComponent } from './menu/breakfast/breakfast.component';
import { DinnerComponent } from './menu/dinner/dinner.component';
import { FastFoodComponent } from './menu/fast-food/fast-food.component';
import { LunchComponent } from './menu/lunch/lunch.component';
import { SaladsComponent } from './menu/salads/salads.component';
import { CustomerAboutComponent } from './customer/customer-about/customer-about.component';
import { CustomerGalleryComponent } from './customer/customer-gallery/customer-gallery.component';
import { CustomerContactComponent } from './customer/customer-contact/customer-contact.component';
import { SearchComponent } from './search/search.component';
import { AdminLoginComponent } from './adminpage/admin-login/admin-login.component';
import { AdminComponent } from './adminpage/admin/admin.component';
import { AboutComponent } from './Public/about/about.component';

import { PaymentComponent } from './customer/payment/payment.component';
import { HomeNavbarComponent } from './Public/home-navbar/home-navbar.component';
import { FooterComponent } from './Public/footer/footer.component';
import { RegistrationComponent } from './customer/TableBooking/registration/registration.component';
import { ReserveComponent } from './customer/TableBooking/reserve/reserve.component';
import { CancelComponent } from './customer/TableBooking/cancel/cancel.component';
import { HomeComponent } from './Public/home/home.component';
import { ContactUsComponent } from './Public/contact-us/contact-us.component';
import { ScrollTopComponent } from './Public/scroll-top/scroll-top.component';
import { LoginComponent } from './customer/login/login.component';
import { RegisterComponent } from './customer/register/register.component';

import { NgxPaginationModule} from 'ngx-pagination'


@NgModule({
  declarations: [
    AppComponent,
    CustomerNavbarComponent,
    CustomerCartComponent,
    HomeNavbarComponent,
    FooterComponent,
    AboutComponent,
    ContactUsComponent,
    GalleryComponent,
    AllphotosComponent,
    InteriorComponent,
    EventsComponent,
    VipComponent,
    RegistrationComponent,
    ReserveComponent,
    CancelComponent,
    HomeComponent,
    LogoutComponent,
    CustomerHomeComponent,
    ScrollTopComponent,
    BreadsComponent,
    BreakfastComponent,
    DinnerComponent,
    FastFoodComponent,
    LunchComponent,
    SaladsComponent,
    CustomerAboutComponent,
    CustomerGalleryComponent,
    CustomerContactComponent,
    SearchComponent,
    AdminLoginComponent,
    AdminComponent,
    PaymentComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatToolbarModule,
    FlexLayoutModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    MatButtonModule,
    MatMenuModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    Material,
    MatChipsModule,
    MatButtonToggleModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
