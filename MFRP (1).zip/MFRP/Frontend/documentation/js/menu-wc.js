'use strict';

customElements.define('compodoc-menu', class extends HTMLElement {
    constructor() {
        super();
        this.isNormalMode = this.getAttribute('mode') === 'normal';
    }

    connectedCallback() {
        this.render(this.isNormalMode);
    }

    render(isNormalMode) {
        let tp = lithtml.html(`
        <nav>
            <ul class="list">
                <li class="title">
                    <a href="index.html" data-type="index-link">angular-handson documentation</a>
                </li>

                <li class="divider"></li>
                ${ isNormalMode ? `<div id="book-search-input" role="search"><input type="text" placeholder="Type to search"></div>` : '' }
                <li class="chapter">
                    <a data-type="chapter-link" href="index.html"><span class="icon ion-ios-home"></span>Getting started</a>
                    <ul class="links">
                        <li class="link">
                            <a href="overview.html" data-type="chapter-link">
                                <span class="icon ion-ios-keypad"></span>Overview
                            </a>
                        </li>
                        <li class="link">
                            <a href="index.html" data-type="chapter-link">
                                <span class="icon ion-ios-paper"></span>README
                            </a>
                        </li>
                                <li class="link">
                                    <a href="dependencies.html" data-type="chapter-link">
                                        <span class="icon ion-ios-list"></span>Dependencies
                                    </a>
                                </li>
                                <li class="link">
                                    <a href="properties.html" data-type="chapter-link">
                                        <span class="icon ion-ios-apps"></span>Properties
                                    </a>
                                </li>
                    </ul>
                </li>
                    <li class="chapter modules">
                        <a data-type="chapter-link" href="modules.html">
                            <div class="menu-toggler linked" data-toggle="collapse" ${ isNormalMode ?
                                'data-target="#modules-links"' : 'data-target="#xs-modules-links"' }>
                                <span class="icon ion-ios-archive"></span>
                                <span class="link-name">Modules</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                        </a>
                        <ul class="links collapse " ${ isNormalMode ? 'id="modules-links"' : 'id="xs-modules-links"' }>
                            <li class="link">
                                <a href="modules/AppModule.html" data-type="entity-link" >AppModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-AppModule-99e05a91fc3c1f296f86e3793a7fc5cd5566e2cd68e5db98cfd3d09cf0cbd4a510ba12d805b2fd0f7cc0c3bbdfa651a029fd3f8bf40ae6ff0105aba523fd62e9"' : 'data-target="#xs-components-links-module-AppModule-99e05a91fc3c1f296f86e3793a7fc5cd5566e2cd68e5db98cfd3d09cf0cbd4a510ba12d805b2fd0f7cc0c3bbdfa651a029fd3f8bf40ae6ff0105aba523fd62e9"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-AppModule-99e05a91fc3c1f296f86e3793a7fc5cd5566e2cd68e5db98cfd3d09cf0cbd4a510ba12d805b2fd0f7cc0c3bbdfa651a029fd3f8bf40ae6ff0105aba523fd62e9"' :
                                            'id="xs-components-links-module-AppModule-99e05a91fc3c1f296f86e3793a7fc5cd5566e2cd68e5db98cfd3d09cf0cbd4a510ba12d805b2fd0f7cc0c3bbdfa651a029fd3f8bf40ae6ff0105aba523fd62e9"' }>
                                            <li class="link">
                                                <a href="components/AboutComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AboutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AdminComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AdminComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AdminLoginComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AdminLoginComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AllphotosComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AllphotosComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AppComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BreadsComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >BreadsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BreakfastComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >BreakfastComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CancelComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CancelComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ContactUsComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ContactUsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CustomerAboutComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CustomerAboutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CustomerCartComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CustomerCartComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CustomerContactComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CustomerContactComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CustomerGalleryComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CustomerGalleryComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CustomerHomeComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CustomerHomeComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CustomerNavbarComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CustomerNavbarComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DinnerComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >DinnerComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/EventsComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EventsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FastFoodComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >FastFoodComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FoodOrderComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >FoodOrderComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >FooterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/GalleryComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >GalleryComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HomeComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >HomeComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HomeNavbarComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >HomeNavbarComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/InteriorComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >InteriorComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoginregisterComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LoginregisterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LogoutComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LogoutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LunchComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LunchComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RegistrationComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >RegistrationComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ReserveComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ReserveComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/SaladsComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >SaladsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ScrollTopComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ScrollTopComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/SearchComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >SearchComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/TagsComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >TagsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/VipComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >VipComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                            </li>
                            <li class="link">
                                <a href="modules/AppRoutingModule.html" data-type="entity-link" >AppRoutingModule</a>
                            </li>
                            <li class="link">
                                <a href="modules/Material.html" data-type="entity-link" >Material</a>
                            </li>
                </ul>
                </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#components-links"' :
                            'data-target="#xs-components-links"' }>
                            <span class="icon ion-md-cog"></span>
                            <span>Components</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="components-links"' : 'id="xs-components-links"' }>
                            <li class="link">
                                <a href="components/AllphotosComponent-1.html" data-type="entity-link" >AllphotosComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/EventsComponent-1.html" data-type="entity-link" >EventsComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/FoodComponent.html" data-type="entity-link" >FoodComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/FoodComponent-1.html" data-type="entity-link" >FoodComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/InteriorComponent-1.html" data-type="entity-link" >InteriorComponent</a>
                            </li>
                            <li class="link">
                                <a href="components/VipComponent-1.html" data-type="entity-link" >VipComponent</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#classes-links"' :
                            'data-target="#xs-classes-links"' }>
                            <span class="icon ion-ios-paper"></span>
                            <span>Classes</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="classes-links"' : 'id="xs-classes-links"' }>
                            <li class="link">
                                <a href="classes/Cart.html" data-type="entity-link" >Cart</a>
                            </li>
                            <li class="link">
                                <a href="classes/Cart-1.html" data-type="entity-link" >Cart</a>
                            </li>
                            <li class="link">
                                <a href="classes/CartItem.html" data-type="entity-link" >CartItem</a>
                            </li>
                            <li class="link">
                                <a href="classes/Foods.html" data-type="entity-link" >Foods</a>
                            </li>
                            <li class="link">
                                <a href="classes/Tag.html" data-type="entity-link" >Tag</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#injectables-links"' :
                                'data-target="#xs-injectables-links"' }>
                                <span class="icon ion-md-arrow-round-down"></span>
                                <span>Injectables</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                            <ul class="links collapse " ${ isNormalMode ? 'id="injectables-links"' : 'id="xs-injectables-links"' }>
                                <li class="link">
                                    <a href="injectables/AdminService.html" data-type="entity-link" >AdminService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/AuthService.html" data-type="entity-link" >AuthService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/CartService.html" data-type="entity-link" >CartService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/HttpService.html" data-type="entity-link" >HttpService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/ReserveService.html" data-type="entity-link" >ReserveService</a>
                                </li>
                            </ul>
                        </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#interfaces-links"' :
                            'data-target="#xs-interfaces-links"' }>
                            <span class="icon ion-md-information-circle-outline"></span>
                            <span>Interfaces</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? ' id="interfaces-links"' : 'id="xs-interfaces-links"' }>
                            <li class="link">
                                <a href="interfaces/Idata.html" data-type="entity-link" >Idata</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/Menu.html" data-type="entity-link" >Menu</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/Table.html" data-type="entity-link" >Table</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#miscellaneous-links"'
                            : 'data-target="#xs-miscellaneous-links"' }>
                            <span class="icon ion-ios-cube"></span>
                            <span>Miscellaneous</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="miscellaneous-links"' : 'id="xs-miscellaneous-links"' }>
                            <li class="link">
                                <a href="miscellaneous/functions.html" data-type="entity-link">Functions</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/variables.html" data-type="entity-link">Variables</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <a data-type="chapter-link" href="routes.html"><span class="icon ion-ios-git-branch"></span>Routes</a>
                        </li>
                    <li class="chapter">
                        <a data-type="chapter-link" href="coverage.html"><span class="icon ion-ios-stats"></span>Documentation coverage</a>
                    </li>
                    <li class="divider"></li>
                    <li class="copyright">
                        Documentation generated using <a href="https://compodoc.app/" target="_blank">
                            <img data-src="images/compodoc-vectorise.png" class="img-responsive" data-type="compodoc-logo">
                        </a>
                    </li>
            </ul>
        </nav>
        `);
        this.innerHTML = tp.strings;
    }
});