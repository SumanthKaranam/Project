const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const nodemailer = require("nodemailer");

//const details = require("./details.json");

const app = express();
app.use(cors({ origin: "*" }));
app.use(bodyParser.json());

app.listen(3000, () => {
  console.log("The server started on port 3000 !!!!!!");
});

app.get("/", (req, res) => {
  res.send(
    "<h1 style='text-align: center'>Wellcome to FunOfHeuristic <br><br></h1>"
  );
});

app.post("/sendmail", (req, res) => {
  console.log("request came");
  let user = req.body;
  sendMail(user, info => {
    console.log(`The mail has been send and the id is ${info.messageId}`);
    res.send(info);
  });
});

async function sendMail(user, callback) {
  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    service: "gmail",
    host: "smtp.ethereal.email",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      //user: details.email,
      //pass: details.password
      user: "demorestaurant04@gmail.com",
      pass: "demotest04"

    }
  });

  let mailOptions = {
   // from: '"bhanu" <bhanutejabbt99@gmail.com>', // sender address
   from: 'demorestaurant04@gmail.com',
    to: user.email, // list of receivers
    subject: "Welcome to our Restaurant", // Subject line
    html: `<h1>Hi ${user.name}</h1><br>
    <h4>Thank you for your valuable feedback</h4>
    <h3>Your response is</h3><br>
    <h4>Name: ${user.name}<br>
    Message: ${user.message}</h4>`
  };

  // send mail with defined transport object
  let info = await transporter.sendMail(mailOptions);

  callback(info);
}