const express = require('express')
const app = express()
const api = require('./api')
const morgan = require('morgan')
const bodyparser = require('body-parser')
const cors = require('cors')
const nodemailer = require("nodemailer");

//
const env = require('dotenv').config()
const ejs = require('ejs')
const path = require('path')
const session = require('express-session')
const MongoStore = require('connect-mongo')(session)


app.set('port', (process.env.PORT || 1000))

app.use(express.json())
app.use(express.urlencoded({ extended: false}))

app.use(cors())

app.use('/api', api)
app.use(express.static('static'))

app.use(morgan('dev'))

app.use(function(req, res) {
    const err = new Error('Not Found')
    err.status = 404
    res.json(err)
})


// MongoDB connection
const mongoose = require('mongoose')
const beautifyUnique = require('mongoose-beautiful-unique-validation');

mongoose.set('useCreateIndex', true);
mongoose.set('autoIndex', true);

const option = {useCreateIndex: true,autoIndex: true, useNewUrlParser: true}
//mongoose.connect('mongodb://localhost:27017/register', {useNewUrlParser: true})

mongoose.connect('mongodb://localhost:27017/register', option)
const db = mongoose.connection
db.on('error', console.error.bind(console, 'connection error:'))
db.once('open',function() {
    console.log('Connected to MongoDB')

    app.listen(app.get('port'), function() {
        console.log('API server Listening on port ' + app.get('port') + '!')
    })
})

app.use(session({
    secret: 'work hard',
    resave: true,
    saveUninitialized: false,
    store: new MongoStore({
      mongooseConnection: db
    })
  }))

  
