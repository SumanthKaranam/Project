const register = require('../../models/register')
const Register = require('../../models/register')

const Login = require('../../models/login')

const Table = require('../../models/table')
const table = require('../../models/table')

const Menu = require('../../models/menu')
const menu = require('../../models/menu')

const Cart = require('../../models/cart')

//
const bcrypt = require('bcryptjs')
module.exports = function (router) {
    
    // POST FOR REGISTER
    router.post('/register', async (req, res) => {
        var user = new Register({
            username: req.body.username,
            password: req.body.password,
            repassword: req.body.repassword
        });
        Register.find({ username: req.body.username }, (err, users) => {

            if (err) {
                //console.log("error in finding email ");
                res.json({ msg: "some error!" });
            }
            else if (users.length != 0) {
                // console.log("already user with this email");
                res.json({ msg: " Username already exists" });
            }
            else if (req.body.password != req.body.repassword) {
                res.json({ msg: "password mismatch" })
            }
            else {
                user.save((error, registeredUser) => {
                    if (error) {
                        console.log("some error");
                        res.json({ msg: "some error!" });
                    }

                    else {
                        console.log("successfully user registered!");
                        res.status(200).json({ message: "successfully registered!" })
                    }
                })
            }
        })
    })



    // GET FOR REGISTER
    router.get('/register', function (req, res) {
        Register.find({}, (err, register) => {
            if (err) {
                res.json({ success: false, message: err });
            } else {
                if (!register) {
                    res.json({ success: false, message: 'No users found' });
                } else {
                    res.json(register);
                }
            }
        })
    })

    // POST -- LOGIN
    router.post('/login', function (req, res, next) {
        var login = new Login({
            username: req.body.username,
            password:req.body.password
        });
        Register.findOne({ username: req.body.username }, function (err, data) {
            if (data) {
                if (data.password == req.body.password) {
                    //req.session.username=data.username;
                    login.save((err, loginUsers) => {
                        if(err) {
                            res.json({msg:"Some error"})
                        } else {
                            res.json({ success: true, id: data.id, message: 'success' })
                        }
                    })
                    //res.json({ success: true, id: data.id, message: 'success' })
                } else {
                    res.json({ success: false, message: 'wrong password' });
                }
            } else {
                if(req.body.username == "admin123") {
                    if(req.body.password == "QWER12!qwer"){
                        res.json({ success: true, message: "admin"});
                        return 
                    }
                } else {
                    res.json({ success: false, message: 'not registered' });
                }
            } 
            
        });
    });


    // GET -- LOGIN
    router.get('/login/:id', function(req, res) {
        if(!req.params.id) {
            res.json({ success: false, message:"No Id is given"})
        }
        else {
        Login.find({}, (err, loginUsers) => {
            if(err) {
                res.json({ success: false, message: err});
            }
            else {
                if(!loginUsers){
                    res.json({success: false, message:'User Not Registered'})
                } else {
                    res.json(loginUsers);
                }
            }
        })
    }
    })



    // POST -- TABLE RESERVATION
    router.post('/reserve', (req, res, next) => {
        var reserve = new Table({
            username: req.body.username,
            contact: req.body.contact,
            codename: req.body.codename
        });
        Register.findOne({ username: req.body.username }, function (err, datas) {
            if (datas) {
                if (datas.username == req.body.username) {
                    Table.find({ username: req.body.username }, (err, users) => {
                        if (users.length != 0) {
                            res.json({ msg: 'Already exists' })
                        } else {
                            reserve.save((errors, reservedUser) => {
                                if (errors) {
                                    res.json({ msg: "some error!" });
                                } else {
                                    res.status(200).json({ success: true, message: 'Reservation done' })
                                }
                            })
                        }
                    })

                    //res.json({success: true, message: 'Reservation done'})
                } else {
                    res.json({ success: false, message: 'Not registered' })
                }
            }
            else {
                res.json({ msg: "Not a valid user" })
            }
        })
    })


    // GET -- TABLE RESERVATION
    router.get('/reserve', function (req, res) {
        Table.find({}, (err, reserver) => {
            if (err) {
                res.json({ success: false, message: err });
            } else {
                if (!reserver) {
                    res.json({ success: false, message: 'No reservers' })
                } else {
                    res.json(reserver);
                }
            }
        })
    })

    // DELETE --CANCEL RESERVATION
    router.delete('/cancel/:codename', function (req, res) {
        if (!req.params.codename) {
            res.json({ success: false, message: 'No code is given' })
        } else {
            Table.findOne({ codename: req.params.codename }, (err, reserve) => {
                if (err) {
                    res.json({ success: false, message: 'Invalid codename' });
                } else {
                    if (!reserve) {
                        res.json({ success: false, message: 'not a valid code' });
                    } else {
                        reserve.remove((err) => {
                            res.json({ success: true, message: 'Reservation cancelled' });
                        })
                    }
                }
            })
        }
    });

    // POST FOR ADMIN
    router.post('/add', function (req, res) {
        let foodItems = new Menu(req.body)
        foodItems.save(function (err, foodItems) {
            if (err) {
                return res.status(400).json(err)
            }
            res.status(200).json(foodItems)
        })
    })

    // GET FOR ADMIN
    router.get('/getMenu', function (req, res) {
        Menu.find({}, (err, menu) => {
            if (err) {
                res.json({ success: false, message: err });
            } else {
                if (!menu) {
                    res.json({ success: false, message: 'No Food items found' });
                } else {
                    res.json(menu);
                }
            }
        })
    })

    // GET BY NAME
    router.get('/getByName/:name', function (req, res) {
        if (!req.params.name) {
            res.json({ success: false, message: 'No Name is provided' })
        } else {
            Menu.find({ name: req.params.name }, (err, foodItems) => {
                if (err) {
                    res.json({ success: false, message: 'Invalid Name' })
                } else {
                    if (!foodItems) {
                        res.json({ success: false, message: 'Not a valid Name' })
                    }
                    else {
                        res.json(foodItems)
                    }
                }
            })
        }
    })


    // GET FOR ADMIN (BY TAG NAME)
    router.get('/getByTag/:tags', function (req, res) {
        if (!req.params.tags) {
            res.json({ success: false, message: 'No Tag is provided' })
        } else {
            Menu.find({ tags: req.params.tags }, (err, foodItems) => {
                if (err) {
                    res.json({ success: false, message: 'Invalid Tagname' })
                } else {
                    if (!foodItems) {
                        res.json({ success: false, message: 'Not a valid Tag' })
                    }
                    else {
                        res.json(foodItems)
                    }
                }
            })
        }
    })

    //PUT FOR ADMIN
    router.put('/updateMenu', (req, res) => {
        if (!req.body.name) {
            res.json({ success: false, message: 'No Items found' });
        } else {
            Menu.findOne({ name: req.body.name }, (err, foodItems) => {
                if (err) {
                    res.json({ success: false, message: 'Not a valid name' });
                } else {
                    foodItems.name = req.body.name;
                    foodItems.price = req.body.price;
                    foodItems.tags = req.body.tags;
                    // foodItems.image = req.body.image;
                    foodItems.origin = req.body.origin;
                    foodItems.save((err) => {
                        if (err) {
                            res.json({ success: false, message: err });
                        } else {
                            res.json({ success: true, message: 'Menu Updated' })
                        }
                    });
                }
            });
        }
    });


    // DELETE FOR ADMIN
    router.delete('/deleteFood/:name', (req, res) => {
        if (!req.params.name) {
            res.json({ success: false, message: 'No Name is provides' });
        } else {
            Menu.findOne({ name: req.params.name }, (err, foodItems) => {
                if (err) {
                    res.json({ success: false, message: 'Invalid name' });
                } else {
                    if (!foodItems) {
                        res.json({ success: false, message: 'Not a valid name' });
                    } else {
                        foodItems.remove(() => {
                            res.json({ success: true, message: 'Food Item deleted' });
                        });
                    }
                }
            });
        }
    });

    //cart
    router.post("/addToCart", function (req, res) {
        let foodItems = new Cart(req.body);

        foodItems.save(function (err, foodItems) {
            if (err) {
                return res.status(400).json(err);
            }

            res.status(200).json(foodItems);
        });
    });

    router.get("/getCart/:id", function (req, res) {
        if (!req.params.id) {
            res.json({ success: false, message: "No iD is provided" });
        } else {
            Cart.find({ userId: req.params.id }, (err, foodItems) => {
                if (err) {
                    res.json({ success: false, message: "Invalid iD" });
                } else {
                    if (!foodItems) {
                        res.json({ success: false, message: "Not a valid iD" });
                    } else {
                        res.json(foodItems);
                    }
                }
            });
        }
    });

    router.delete("/delcartitem/:id", (req, res) => {
        var id = req.params.id;
        Cart.remove({ id: id }, (err) => {
            if (err) {
                console.log("");
            }
        });
        res.status(200).json({ msg: "deleted item" });
    });

    router.delete("/delallitems/:id", (req, res) => {
        var id = req.params.id;
        Cart.remove({ userId: id }, (err) => {
            if (err) {
                console.log("");
            }
        });
        res.status(200).json({ msg: "deleting all items" });
    });

    router.post("/delcartitem", (req, res) => {
        var id = req.body.id;
        var userId = req.body.userId;
        Cart.remove({ id: id, userId: userId }, (err) => {
            if (err) {
                console.log("");
            }
        });
        res.status(200).json({ msg: "deleted item" });
    });


}


