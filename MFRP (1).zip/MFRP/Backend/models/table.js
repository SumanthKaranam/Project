const mongoose = require('mongoose')

const tableSchema = new mongoose.Schema({
    username: {type: String, required: true},
    contact: {type: String, required: true },
    codename: {type: String, required: true }
})

module.exports = mongoose.model('Table', tableSchema)