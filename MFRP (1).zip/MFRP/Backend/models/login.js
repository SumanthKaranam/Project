const mongoose = require('mongoose')

let loginSchema = mongoose.Schema({
    userId: { type: String},
    username: {type: String, required: true},
    password: {type: String, required: true }
})


module.exports = mongoose.model('Login', loginSchema)


