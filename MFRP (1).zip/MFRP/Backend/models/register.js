const mongoose = require('mongoose')
let beautifyUnique = require('mongoose-beautiful-unique-validation');

let registerSchema = mongoose.Schema({
    username: {type: String, unique: true, required: true},
    password: {type: String, required: true },
    repassword: {type: String, required: true },
})

registerSchema.plugin(beautifyUnique);


module.exports = mongoose.model('Register', registerSchema)


