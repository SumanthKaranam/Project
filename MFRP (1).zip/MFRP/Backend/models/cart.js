const mongoose = require('mongoose')



const cartSchema = new mongoose.Schema({
    userId: { type: String},

    username:{type: String},

    id: {type: Number},

    name: {type: String},

    price: {type: String},

    tags: {type:Array},

    image: {type: String},

    origins: {type : String}

})



module.exports = mongoose.model('Cart', cartSchema)