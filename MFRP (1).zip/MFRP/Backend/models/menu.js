const mongoose = require('mongoose')

const menuSchema = new mongoose.Schema({
    id: {type: Number},
    name: {type: String},
    price: {type: String},
    tags: {type:Array},
    image: {type: String},
    origins: {type : String}
})

module.exports = mongoose.model('Menu', menuSchema)